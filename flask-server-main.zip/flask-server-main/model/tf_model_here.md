# TensorFlow Model Directory

Place your model files here. This sample looks to this location to find model files and a file with metadata about the model. 

* When you export your model from Lobe, move the contents of that folder here. The contents are:
    * `saved_model.pb`
    * `variables/`
    * `signature.json`
